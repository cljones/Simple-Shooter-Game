/*
 * The enemy invaders to be shot at.
 */



import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;




public class Invader{
    private double centerX;
    private double centerY;
    private double width;
    private double height;
    private Ellipse body;
    private Color color;
    private double speed;   
    private Pane InvaderPane = new Pane();

    /**
     *
     * @return
     */
    public double getWidth() {
        return width;
    }

    /**
     *
     * @param width
     */
    public void setWidth(double width) {
        this.width = width;
    }

    /**
     *
     * @return
     */
    public double getHeight() {
        return height;
    }

    /**
     *
     * @param height
     */
    public void setHeight(double height) {
        this.height = height;
    }

    /**
     *
     * @param centerX
     * @param centerY
     * @param width
     * @param height
     * @param color
     * @param speed
     */
    public Invader(double centerX, double centerY, double width, double height, 
            Color color, double speed) {
        this.centerX = centerX;
        this.centerY = centerY;
        this.width = width;
        this.height = height;

        this.color = color;
        this.speed = speed;
        //this.pane = pane;
        
        this.body = new Ellipse();
        
          
        InvaderPane.getChildren().add(body);
        
        
        drawInvader();
        
    }

    /**
     * 
     * @return - a value is returned
     */
    public double getCenterX() {
        return centerX;
    }

    /**
     * A place for the invader
     * @param centerX - a place on X-axis
     */
    public void setCenterX(double centerX) {
        this.centerX = centerX;
        
    }

    /**
     * Places invader on the Y-axis
     * @return - a value is returned
     */
    public double getCenterY() {
        return centerY;
    }

    /**
     * A place for the invader
     * @param centerY - place on the Y-axis
     */
    public void setCenterY(double centerY) {
        this.centerY = centerY;
    }

    /**
     * The body is obtained
     * @return - a value is returned
     */
    public Ellipse getBody() {
        return body;
    }

    /**
     * The body of the invader is set
     * @param body - body of the invader
     */
    public void setBody(Ellipse body) {
        this.body = body;
    }

    /**
     * A color is obtained
     * @return - a value is returned
     */
    public Color getColor() {
        return color;
    }

    /**
     * A color is set
     * @param color - the color is a parameter
     */
    public void setColor(Color color) {
        this.color = color;
    }

    /**
     * The speed is obtained
     * @return - value is returned
     */
    public double getSpeed() {
        return speed;
    }

    /**
     * The value of the speed is manipulated
     * @param speed - the value for the speed
     */
    public void setSpeed(double speed) {
        this.speed = speed;
    }

    /**
     * The pane is being retrieved
     * @return - a value is returned
     */
    public Pane getPane() {
        return InvaderPane;
    }



    /**
     * The invader is drawn
     */
    public void drawInvader() {
        //Body of invader
        body.setFill(color); //Set random body color
        body.setCenterX(centerX);
        body.setCenterY(centerY);
        body.setRadiusY(height);
        body.setRadiusX(width);
     }
     
    /**
     * The invaders will be moving to the right
     */
    public void moveRight()
     {
         centerX++;
         
         drawInvader();
     }
     
    /**
     * This destroys the invader
     */
    public void destroyInvader(){
         InvaderPane.getChildren().remove(body);
         
     }
}
