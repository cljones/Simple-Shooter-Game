/*
 * This program is a simple shooter game
 */

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.input.MouseButton;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * Chappell Jones
 * CS 1180-03
 * Lifeng Liu
 * Vanessa Starkey
 */
public class ShooterGame extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        InvaderPane pane = new InvaderPane();
        
        //Value of dimensions for keeping score
        HBox hBox = new HBox();
        
        TextField text = new TextField();
        Label label = new Label("Score: ");
        hBox.getChildren().add(label);
        hBox.getChildren().add(text);
        hBox.setAlignment(Pos.CENTER);
        BorderPane bPane = new BorderPane();
        text.setMaxWidth(100);
        bPane.setCenter(pane);
        bPane.setBottom(hBox);
        text.setAlignment(Pos.CENTER);
        bPane.setAlignment(hBox,Pos.CENTER);
               
        //The Scene
        Scene scene = new Scene(bPane, 400, 450);   
        pane.setStyle("-fx-background-color: gold");
        pane.setText(text);
        primaryStage.setTitle("Shooter Game Fall 2014");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
        pane.requestFocus();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
