import javafx.scene.text.Font;
import javafx.scene.text.Text;

/*
 * The explosion for after when the ships get hit by the bullet.
 */

public class Boom {

    private InvaderPane pane;
    private double centerX;
    private double centerY;
    private Text text;
    private int timer=0;

    /**
     * The construct for building the Boom
     * @param centerX - the place on the X-axis
     * @param centerY - the place on the Y-axis
     * @param pane - the InvaderPane
     */
    public Boom(double centerX,double centerY, InvaderPane pane) {
        
        
        this.centerX = centerX;
        this.centerY = centerY ;
        this.pane = pane;
        this.text= new Text("BOOM!!");
        
        pane.getChildren().add(text);
        
        drawBoom();
    }
 

        
    /**
     * This gets pane for the InvaderPane
     * @return - returns a value
     */
    public InvaderPane getPane() {
        return pane;
    }

    /**
     * Setting of the pane
     * @param pane - the value for the game pane
     */
    public void setPane(InvaderPane pane) {
        this.pane = pane;
    }


    /**
     * The boom is draw via text
     */
    public void drawBoom() {
        text.setX(centerX);
        text.setY(centerY);
        text.setFont(new Font(10));
        
    }

    /**
     * The timer is increased
     */
    public void increaseTimer()
    {
        timer++;
    }

    /**
     * The timer to control the explosion time
     * @return - a value to be returned 
     */
    public int getTimer()
    {
        return timer;
    }

    /**
     * The text disappears
     */
    public void destroy()
    {
        text.setText(null);
    }
}
