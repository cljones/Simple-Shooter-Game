/*
 * The projectile for hitting the enemy invaders.
 */

import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;


public class Bullet{
    private Circle bullet;
    private double radius;
    private double centerX;
    private double centerY;
    private Color color;
    private InvaderPane pane;

    /**
     * The constructor for the dimensions of the bullet
     * @param radius - the size of the bullet
     * @param centerX - the place on the X-axis
     * @param centerY - the place on the Y-axis
     * @param pane - the pane for the game pane
     */
    public Bullet(double radius,double centerX,double centerY, InvaderPane pane) {
        this.bullet = new Circle();
        this.radius = radius;
        this.centerX = centerX;
        this.centerY = centerY;
       
        this.pane = pane;
        
        pane.getChildren().add(bullet);
        drawBullet();
    }

    /**
     * Bullet shape is created
     * @return - a value is returned
     */
    public Circle getBullet() {
        return bullet;
    }

    /**
     * Bullet is placed in the X-axis
     * @return - a value is returned
     */
    public double getCenterX() {
        return centerX;
    }

    /**
     * Place for the bullet
     * @param centerX - the place on the X-axis
     */
    public void setCenterX(double centerX) {
        this.centerX = centerX;
    }

    /**
     * Bullet is placed in the Y-axis
     * @return - a value is returned
     */
    public double getCenterY() {
        return centerY;
    }

    /**
     * Place for the bullet
     * @param centerY - the place on the Y-axis
     */
    public void setCenterY(double centerY) {
        this.centerY = centerY;
    }

    /**
     * Bullet is to be set
     * @param bullet - bullet for the launcher
     */
    public void setBullet(Circle bullet) {
        this.bullet = bullet;
    }

    /**
     * Size of bullet is gained
     * @return - value is returned
     */
    public double getRadius() {
        return radius;
    }

    /**
     * Size the bullet to be set
     * @param radius - radius to be set
     */
    public void setRadius(double radius) {
        this.radius = radius;
    }

    /**
     * Color is gained
     * @return - value to be returned
     */
    public Color getColor() {
        return color;
    }

    /**
     * Color is to be set
     * @param color - color is set
     */
    public void setColor(Color color) {
        this.color = color;
    }

    /**
     * Obtains the game pane
     * @return - value is returned
     */
    public InvaderPane getPane() {
        return pane;
    }

    /**
     * Pane is set
     * @param pane- game pane
     */
    public void setPane(InvaderPane pane) {
        this.pane = pane;
    }
    
    /**
     * Bullet is Drawn
     */
    public void drawBullet(){
        
       
        color = new Color(Math.random(), Math.random(), Math.random(), 1.0);
        bullet.setFill(color); //Set random body color

        bullet.setRadius(5);
        bullet.setCenterX(centerX);
        bullet.setCenterY(centerY);
        
        
    }
    
    /**
     * Moves the bullet
     */
    public void moveBullet(){
        
        centerY-= 10;
        drawBullet();
    }
    
    /**
     * Removes bullet
     */
    public void removeBullet(){
        
        pane.getChildren().remove(bullet);
        
    }
    
}
