/*
 * The launcher to shoot the enemies.
 */

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class Launcher {

    private double centerX;
    private double centerY;
    private double width;
    private double height;
    private double C_width;
    private double C_height;
    private Color color;
    private double speed;
    private double centery;//do not needed
    private Rectangle cannon;
    private Rectangle body;
    private InvaderPane pane;

    /**
     *
     * @param centerX
     * @param centerY
     * @param height
     * @param width
     * @param C_height
     * @param speed
     * @param pane
     */
    public Launcher(double centerX, double centerY, double height, double width,double C_height,double C_width, double speed,  InvaderPane pane) {
        this.centerX = centerX;
        this.centerY = centerY;
        this.speed = speed;
        this.width=width;
        this.height=height;
        this.C_height = C_height;
        this.C_width= C_width;
        this.cannon = new Rectangle();
        this.body = new Rectangle();
        this.pane = pane;

        this.pane.getChildren().add(this.cannon);
        this.pane.getChildren().add(this.body);
        drawLauncher();
        drawLCannon();
    }

    /**
     *
     * @return
     */
    public double getCenterX() {
        return centerX;
    }

    /**
     *
     * @param centerX
     */
    public void setCenterX(double centerX) {
        this.centerX = centerX;
    }

    /**
     *
     * @return
     */
    public double getCenterY() {
        return centerY;
    }

    /**
     *
     * @param centerY
     */
    public void setCenterY(double centerY) {
        this.centerY = centerY;
    }

    /**
     *
     * @return
     */
    public Color getColor() {
        return color;
    }

    /**
     *
     * @param color
     */
    public void setColor(Color color) {
        this.color = color;
    }

    /**
     *
     * @return
     */
    public double getSpeed() {
        return speed;
    }

    /**
     *
     * @param speed
     */
    public void setSpeed(double speed) {
        this.speed = speed;
    }

    /**
     *
     * @return
     */
    public double getCentery() {
        return centery;
    }

    /**
     *
     * @param centery
     */
    public void setCentery(double centery) {
        this.centery = centery;
    }

    /**
     *
     * @return
     */
    public Rectangle getCannon() {
        return cannon;
    }

    /**
     *
     * @param cannon
     */
    public void setCannon(Rectangle cannon) {
        this.cannon = cannon;
    }

    /**
     *
     * @return
     */
    public Rectangle getBody() {
        return body;
    }

    /**
     *
     * @param body
     */
    public void setBody(Rectangle body) {
        this.body = body;
    }

    /**
     *
     * @return - returns value for game pane
     */
    public InvaderPane getPane() {
        return pane;
    }

    /**
     * The variable for the game pane
     * @param pane - the variable for the game pane
     */
    public void setPane(InvaderPane pane) {
        this.pane = pane;
    }

    
    /**
     * Draws the body of the launcher
     */
    public void drawLauncher() {
        //The body of the launcher
        this.body.setFill(Color.RED); //Set body color
        this.body.setHeight(this.height);
        this.body.setWidth(this.width);
        body.setX(centerX-width*0.5);
        body.setY(centerY);
        

    }

    /**
     * Draws the cannon
     */
    public void drawLCannon() {
        //this.cannon = new Rectangle(); //Set cannon color
        this.cannon.setFill(Color.BLACK);
        this.cannon.setHeight(this.C_height);
        this.cannon.setWidth(this.C_width);
        cannon.setX(centerX-C_width * 0.5);
        
        cannon.setY(centerY-C_height);
        
    }

    /**
     * Moves the launcher to the left
     */
    public void moveLeft() {
      centerX-=7; 
      drawLCannon();
      drawLauncher();
    }
    
    /**
     * Moves the launcher to the right
     */
    public void moveRight() {
            centerX+=7;
            drawLCannon();
            drawLauncher();
    }
}
