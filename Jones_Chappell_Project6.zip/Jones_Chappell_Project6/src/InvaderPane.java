
import java.util.ArrayList;
import javafx.scene.input.KeyCode;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import javax.swing.JOptionPane;

/*
 * The battlefield and score panel for the game pane.
 */

public class InvaderPane extends Pane {

    private Timeline animation;
    private Timeline animation2;
    private Timeline invaderAct;
    private Timeline invaderAct2;
    private Timeline bulletAct;
    private Timeline explosionAct;
    private Launcher launcher;
    private int score = 0;
    private int miss = 0;
    private Bullet bullet;
    private ArrayList<Invader> invaders;
    private ArrayList< Invader> invaders2nd;
    private ArrayList<Boom> boom;
    private TextField text;
    private TextField text2;

    /**
     * The main game pane
     */
    public InvaderPane() {
        //Top row of invaders
        invaders = new ArrayList();
        boom = new ArrayList();
        //Controls movement
        animation = new Timeline(new KeyFrame(Duration.millis(15),
                e -> {
                    moveOneFrame();
                }
        ));

        this.animation.setCycleCount(Timeline.INDEFINITE);
        this.animation.play();
        //Produces invader
        invaderAct = new Timeline(new KeyFrame(Duration.millis(2500),
                e -> {
                    addInvader();
                }
        ));

        this.invaderAct.setCycleCount(Timeline.INDEFINITE);
        this.invaderAct.play();

        //Bottom row of invaders
        invaders2nd = new ArrayList();
        //Controls movement of invader
        animation2 = new Timeline(new KeyFrame(Duration.millis(25),
                e -> {
                    moveOneFrame();
                }
        ));

        this.animation2.setCycleCount(Timeline.INDEFINITE);
        this.animation2.play();

        //Produces the invader
        invaderAct2 = new Timeline(new KeyFrame(Duration.millis(1500),
                e -> {
                    add2ndInvader();
                }
        ));

        this.invaderAct2.setCycleCount(Timeline.INDEFINITE);
        this.invaderAct2.play();

        //explosion actions
        explosionAct = new Timeline(new KeyFrame(Duration.millis(250),
                e -> {
                    for (int i = 0; i < boom.size(); i++) {
                        Boom b = boom.get(i);
                        b.increaseTimer();
                        if (b.getTimer() > 3) {
                            b.destroy();
                        }
                    }
                }
        ));
        this.explosionAct.setCycleCount(Timeline.INDEFINITE);
        this.explosionAct.play();

        //The launcher   
        this.launcher = new Launcher(200, 409.5, 25, 50, 20, 10, 3.0, this);

        //Launcher movement
        this.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.LEFT) {
                launcher.moveLeft();
            } else if (e.getCode() == KeyCode.RIGHT) {

                launcher.moveRight();

            } else if (e.getCode() == KeyCode.SPACE) {
                if (bullet == null) {
                    bullet = new Bullet(2, launcher.getCenterX(), 350, this);
                }
            }
        });

        //bullet movement
        bulletAct = new Timeline(new KeyFrame(Duration.millis(35),
                e -> {
                    if (bullet != null) {
                        bullet.moveBullet();
                        // Bullet action in the first row
                        for (int i = 0; i < invaders.size(); i++) {

                            Invader ship = invaders.get(i);
                            double x1, x2;
                            double y1, y2;

                            x1 = ship.getCenterX() - ship.getWidth() * 0.5;
                            x2 = ship.getCenterX() + ship.getWidth() * 0.5;
                            y1 = ship.getCenterY() - ship.getHeight() * 0.5;
                            y2 = ship.getCenterY() + ship.getHeight() * 0.5;
                            if (bullet != null && bullet.getCenterX() > x1 && bullet.getCenterX() < x2 && bullet.getCenterY() > y1 && bullet.getCenterY() < y2) {
                                ship.destroyInvader();
                                invaders.remove(ship);
                                score += 100;
                                //Win condition
                                if (score >= 1500) {
                                    JOptionPane.showMessageDialog(null,"You Won!! \n" +
                                             "Your score is " + score + " with only "+ miss +" misses");
                                    score = 0;
                                    miss = 0;
                                    
                                } else if (miss >= 7) {
                                    JOptionPane.showMessageDialog(null,"Your score is " + score 
                                            +" and you had "+ miss+" misses" +
                                    "You Lose!! Try Again");
                                    score = 0;
                                    miss = 0;
                                    
                                }
                                text.setText(score + "");
                                //text2.setText(miss+ "");
                                bullet.removeBullet();
                                bullet = null;

                                boom.add(new Boom(ship.getCenterX(), ship.getCenterY(), this));
                                break;
                            }
                        }
                        // Bullet action in the first row
                        for (int j = 0; j < invaders2nd.size(); j++) {

                            Invader ship = invaders2nd.get(j);
                            double x1, x2;
                            double y1, y2;

                            x1 = ship.getCenterX() - ship.getWidth() * 0.5;
                            x2 = ship.getCenterX() + ship.getWidth() * 0.5;
                            y1 = ship.getCenterY() - ship.getHeight() * 0.5;
                            y2 = ship.getCenterY() + ship.getHeight() * 0.5;
                            if (bullet != null && bullet.getCenterX() > x1 && bullet.getCenterX() < x2 && bullet.getCenterY() > y1 && bullet.getCenterY() < y2) {
                                ship.destroyInvader();
                                invaders2nd.remove(ship);
                                score += 50;
                                //Win condition
                                if (score >= 1500) {
                                    JOptionPane.showMessageDialog(null,"You Won!! \n" +
                                             "Your score is " + score + " with only "+ miss +" misses");
                                    score = 0;
                                    miss = 0;
                                    
                                } else if (miss >= 7) {
                                    
                                    JOptionPane.showMessageDialog(null,"Your score is " + score 
                                            +" and you had "+ miss+" misses\n"
                                            + " You Lose!! Try Again");
                                    score = 0;
                                    miss = 0;
                                    
                                }
                                text.setText(score + "");
                                //text2.setText(miss + "");
                                bullet.removeBullet();
                                bullet = null;
                                boom.add(new Boom(ship.getCenterX(), ship.getCenterY(), this));
                                break;
                            }
                        }

                        if (bullet != null && bullet.getCenterY() < 0) {
                            bullet.removeBullet();
                            bullet = null;
                            miss += 1;
                        }
                    }
                }
        ));

        this.bulletAct.setCycleCount(Timeline.INDEFINITE);
        this.bulletAct.play();

    }

    /**
     * Move the invaders
     */
    public void moveOneFrame() {
        for (int i = 0; i < invaders.size(); i++) {
            invaders.get(i).moveRight();
        }

        for (int j = 0; j < invaders2nd.size(); j++) {
            invaders2nd.get(j).moveRight();
        }

    }

    /**
     * Adds the invaders to the pane
     */
    public void addInvader() {
        //First Row 
        Color color = new Color(Math.random(), Math.random(), Math.random(), 1.0);
        Invader i = new Invader(10, 10.5, 25, 8, color, 2.0);

        invaders.add(i);

        this.getChildren().add(i.getPane());
    }

    /**
     * Adds the 2nd row of invaders to the pane
     */
    public void add2ndInvader() {

        //Second row
        Color color = new Color(Math.random(), Math.random(), Math.random(), 1.0);
        Invader i2 = new Invader(10, 70, 40, 16, color, 2.0);

        invaders2nd.add(i2);

        this.getChildren().add(i2.getPane());

    }

    /**
     * A text message is given
     * @param text - text is placed in the pane
     */
    public void setText(TextField text) {
        this.text = text;
    }

}
